# Dataset source

1000 news articles sampled from the BBC News dataset (D. Greene & P. Cunningham,
ICML 2006; 2,225 articles from 2004-2005; the same data as Kaggle's "BBC News" /
"BBC Full Text Document Classification" datasets), taken from the public GitHub
mirror suraj-deshmukh/BBC-Dataset-News-Classification (dataset/dataset.csv).

Preparation: exact duplicate articles removed (2,124 unique), 1000 sampled with
random seed 42, one article per file (title on the first line, then paragraphs),
UTF-8. Filenames are neutral (article_0001.txt ... article_1000.txt) and no
category labels are included anywhere, so similarity comes only from the text.
